#!/bin/bash

set -ev

sudo apt-get update
sudo apt-get install libsdl1.2-dev libxxf86vm-dev libc6-dev-i386 mingw-w64 gcc-mingw-w64-base gcc-mingw-w64 binutils-mingw-w64