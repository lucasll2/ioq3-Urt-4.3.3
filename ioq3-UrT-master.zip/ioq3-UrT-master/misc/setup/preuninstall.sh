#!/bin/sh
rmdir --ignore-fail-on-non-empty demoq3 missionpack >& /dev/null
