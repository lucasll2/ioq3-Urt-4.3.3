#!/bin/bash

set -ev

make -j 5