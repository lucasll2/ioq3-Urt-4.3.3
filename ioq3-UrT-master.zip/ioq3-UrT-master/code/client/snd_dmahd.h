/*
	DMAEX Hybrid-HRTF Additions by p5yc0runn3r founder of
	Armed, Pissed & Dangerous clan.
*/

#ifndef __SND_DMAHD_H__
#define __SND_DMAHD_H__

#ifndef NO_DMAHD

qboolean dmaHD_LoadSound(sfx_t *sfx);
qboolean dmaHD_Enabled(void);
qboolean dmaHD_Init(soundInterface_t *si);

#endif

#endif//__SND_DMAEX_H__
