#!/bin/bash

set -ev

sudo apt-get update
sudo apt-get install build-essential libsdl1.2-dev libxxf86vm-dev libc6-dev-i386 libxxf86vm-dev libxrandr-dev mesa-common-dev